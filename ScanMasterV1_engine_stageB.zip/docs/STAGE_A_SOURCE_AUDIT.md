# Scan Master V1 — Stage A: Source Audit

Status: **read-only audit of the uploaded Pine files. No calculation has been verified against TradingView.**

## 1. Files received vs. files the spec expected

| Spec name | What actually arrived | Note |
|---|---|---|
| `DIR - OPEn - VM - IB - MP -H -Dias - POC.txt` | `Multi_Stock_Momentum_Dashboard_40_Stocks_No_Blank_Column.txt` | Contents are "Scan Master Set 1 (15.10.26)". It has **20** stock slots, not 40. Treated as the main scanner script. |
| `Gmma - Wt- STCR - ADX -.txt` | `Gmma_-_Wt-_STCR_-_ADX_-.txt` ("Top Bottom 05.10.26 Part 1") | Also contains the STK opening-range / gap / index-% logic (`f_or_*`). |
| `SR.txt` | `SR.txt` ("Volume Trading Original 04.10.26") | Holds IB, GGRR/RRGG, Direction Decider, daily S/R maker, volume mark-up. |
| `Squez momentum.txt` | received | Pine v1/v2 syntax (`study`, `type=bool`). Needs porting. |
| `EMA.txt`, `RSI.txt`, `Multiple RSI.txt` | received | Standard-style scripts. |
| `SF.txt` | received | Reference only. **Not implemented.** |
| `Pasted text(...)` duplicate | not received | Nothing to compare. |

SF code also lives inside the main script (`f_calcSF`, `f_sfs`, SF5 column) and inside the GMMA script (`calc_sf`, returned from `batch`). All of it is excluded.

## 2. Source-to-code mapping

| Column / item | Source file and function | Key rules to preserve |
|---|---|---|
| STK line 1 | app (price, % vs prev close) | Not in Pine; snapshot-consistent. |
| STK `5` / `15` | GMMA file `f_or_opening` | Range % = (H−L)/L×100 over the first 5 or 15 minutes of the regular session. Only published if the last 1-minute bar closed exactly at the window end (`lastClose == end`). Then frozen. |
| STK `G` | `f_or_opening` | `(open − prevDailyClose)/prevDailyClose×100` at first regular bar. |
| DIR | main `f_direction` (and SR `Module 3`) | Reference = previous session's highest-volume 5M candle, excluding first and last candles. A candle is admitted only when a same-session successor exists, `bars >= 2`, `volume > 0`, strict `>` so the **earliest** candle wins ties. At the first bar of the new session: `close > refH → 1`, `close < refL → −1`, else 0. Held all session. |
| Opn | main `f_open` | `open > prevDailyClose → 1`, `< → −1`, equal → 0. Shown as a coloured dot (equal = yellow). No age. |
| 5M | main `f_firstRange` | First regular-session 5M candle `(H−L)/L×100`. Colour: above 0.50 red, below 0.50 lime, equal silver. Threshold is an input. |
| VM | main `f_levels(true)` | Three same-colour candles with strictly rising volume arm a pending setup (range = H/L of the 3 candles). Next bar must continue (same colour and higher volume) or the setup is marked done and its H/L become the lines. First setup per session only. Then strict line-crossing candle → next closed bar must be fully above/below (`low > markH` / `high < markL`) to show ▲(1)/▼(1); count increments per fully separated bar; touch or failure clears. `RT` flag = second or later consecutive same-direction setup. |
| IB | main `f_levels(false)` and SR `Module 1` | Mother-bar setups A (green then red, only low wick breaks) and B (red then green, only high wick breaks). Lines = mother bar H/L. Same crossing/count/RT logic as VM. First per session. |
| MP | main `f_getPocData` | 24 rows over the full session H/L. Each 5M bar's volume is split **equally** across the buckets its low–high spans (difference-array method), not by overlap fraction. POC = lowest bucket with the maximum (strict `>`) → `lo + bucket·step + step/2`. Computed at the last regular bar, activated at the next session. Touch (`low <= poc <= high`) → count reset, pending. Next bar fully above/below → dir ±1, count 1; count grows while fully on that side; failure clears. `RT` = return touch after a qualified move. Display: untouched = yellow ● plus ▲/▼ vs price; touched = ▲(count, ±%). |
| H | main `f_hour` | Exchange-aligned hourly bars (`time("60")`), only full hours count. `SMA(10)` of hourly closes (needs 10). Bull: `close > SMA10 and close > previous hour high`. Bear: mirror with low. Else 0. |
| Bias+ / Bias− | main `f_bias` | Line = `SMA(9, EMA(3, low))` (plus) or `SMA(9, EMA(3, high))` (minus). Touch (`low <= line <= high`) → 0. Next bar: plus needs `low > line` → 1, otherwise −1. Then +1 per bar until the next touch. Output −1 until 150 bars seen (input). |
| SR | SR file `f_srState` (daily) | **Level construction only** (see open question 1). |
| TRIGGER GMMA | GMMA file `f_gmma`, `calc_gmma` | `(Σfast − Σslow)/Σslow×100`, `osc = SMA(raw, smooth=1)`, `sig = EMA(raw, 13)`, `crossover`/`crossunder`. Age starts at 0 on cross, +1 per bar after. Pane version guards divide-by-zero (returns 0), table version does not. Guppy and SuperGuppy both exist. |
| TRIGGER WT | `calc_wt_tri` / `f_wavetrend` | HLC3, `esa = EMA(src, ch)`, `d = EMA(|src−esa|, ch)`, `ci = (src−esa)/(0.015·d)` (0 if d=0), `wt1 = EMA(ci, avg)`, `wt2 = SMA(wt1, 4)`. Source defaults: D 12/24, 1H 10/21, 15M 10/21, 5M 9/12. |
| TRIGGER STCR | `calc_stcr` | `RSI(14)` → `ta.stoch(rsi,rsi,rsi,14)` → K = SMA(3) → D = SMA(3). Cross of K over D. |
| TRIGGER MRSI | Multiple RSI | Source crosses RSI medium over slow. App override: RSI20 vs RSI100. |
| ADX | `calc_adx_di` | `pdm/ndm` from `change(high)` / `−change(low)`; `ta.rma(ta.tr(true), len)`; DI = 100·rma(dm)/atr; `dx = 100·|dip−dim|/(dip+dim+0.000001)`; `adx = rma(dx, len)`. Default 14. Source covers 5M, 15M, 1H, D only. |
| Squeeze | `Squez momentum.txt` | `dev = multKC × stdev` (quirk kept). KC uses SMA of true range. `val = linreg(close − avg(avg(highest(high,20), lowest(low,20)), sma(close,20)), 20, 0)`. |
| EMA / RSI | EMA.txt, RSI.txt | `ta.ema`, `ta.rma`-based RSI with the 100/0 edge cases. |

## 3. Conflicts, gaps and decisions needed

1. **SR column has no signal definition.** `SR.txt` builds daily support/resistance lines (marking-candle high/low) and GGRR/RRGG drawings, but nothing says what the scanner cell should show (price vs level, distance, a cross, an age?). I will not guess. **Needed: what the SR cell displays and when it counts as bullish/bearish.**
2. **Main file is 20 stocks, not 40**, and its name does not match the spec. Confirm this is the right file.
3. **Source behaviours the spec does not mention but I am preserving:** `RT` retest flags on VM, IB and MP; the "signal highlight max n = 4" row shading; the STK row tint rule (`stkDir`); MP percentage display. Say so if you want any removed.
4. **WT 1m and 3m parameters** are not finalized. I will use clearly labelled temporary values (the 5M set 9/12) until you decide.
5. **ADX 4-hour** is not in the source. Spec adds it. Proposed NSE alignment: 09:15–13:15, then 13:15–15:30 (short bar). MCX needs your confirmed session times.
6. **MCX sessions**: the source relies on TradingView's exchange calendar (`time_tradingday`, `session.*`). The app needs explicit MCX hours, including the overnight session and its seasonal end time. Needed from you.
7. **Bias "void" state (−2)** is coloured in the source but never produced. Treated as unused.
8. **STCR and WT strength tiers** come from your spec, not the Pine source. Source only stores K / WT1 at the cross. Fine, but not source-verified.
9. **Squeeze Momentum** is old Pine syntax. Port must replicate: population `stdev`, `tr` on the first bar = high−low, `linreg(...,0)`.
10. **`request.security` behaviour**: Opn uses `lookahead_on` on the daily series (safe, since both values are fixed at the day open); SR uses `mH[1]` with `lookahead_on` (safe, previous daily bar). All 5M scanner outputs are gated by `time_close <= timenow`, i.e. completed candles only. This matches the app's completed-candle policy. Historical TradingView output for these should not repaint.
11. **Warm-up**: source recomputes over up to 1,500 5M bars. The app must fetch comparable history for EMA/RMA states (Angel One limits per request need checking against current docs before promising this).
12. **GMMA table version** uses `Σslow` without a zero guard; the pane version guards. Using the guard; difference only if Σslow is exactly 0.

## 4. Feature status after Stage A

| Area | Status |
|---|---|
| Source audit | DONE (this document) |
| Calculation engine | NOT IMPLEMENTED |
| Android UI | NOT IMPLEMENTED |
| Angel One adapter | NOT IMPLEMENTED |
| Filters / events / alerts | NOT IMPLEMENTED |
| TradingView comparison | NOT TESTED |
| GitHub Actions build | NOT BUILT |
